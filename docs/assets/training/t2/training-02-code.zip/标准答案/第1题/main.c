/* 本题采用基础写法：每个有效语句前均有中文说明。
 * scanf输入须在对应整数类型范围内；计算器结果也须在int范围内。 */
/* 引入标准输入输出头文件，才能使用printf和scanf。 */
#include <stdio.h>
/* 程序从main函数开始执行；void表示不接收参数，int表示返回整数退出状态。 */
int main(void)
{
    /* 声明保存输入值的short整数；本题按16位short讲解。 */
    short int number;
    /* 声明无符号16位变量，保存转换后的数值，便于进行位运算。 */
    unsigned short bits;
    /* 声明两个无符号字节变量，分别保存高8位和低8位。 */
    unsigned char high, low;
    /* 显示输入提示并换行，让用户知道需要输入short范围内的整数。 */
    printf("请输入一个short整数：\n");
    /* %hd读取short，&number给出存储地址；返回值不是1说明没有成功读入一个整数。 */
    if (scanf("%hd", &number) != 1) {
        /* 提示输入未成功；\n表示换行。 */
        printf("输入错误。\n");
        /* 结束整个程序并返回1，表示本次运行因输入错误而失败。 */
        return 1;
    }
    /* 将有符号输入转换为无符号数，负数也可用确定的低16位数值参与右移。 */
    bits = (unsigned short)number;
    /* 0xFF的低8位是1、高位是0；按位与后仅保留原数低8位。 */
    low = bits & 0xFF;
    /* 先右移8位把原高字节移到低位，再与0xFF提取这8位。 */
    high = (bits >> 8) & 0xFF;
    /* 输出高字节；%02X表示大写十六进制，至少两位，不足补0。 */
    printf("高字节：0x%02X\n", high);
    /* 用相同格式输出低字节，方便和高字节对照。 */
    printf("低字节：0x%02X\n", low);
    /* 小端低地址存低字节，所以先输出low，再输出high；这里只模拟顺序。 */
    printf("小端序（低地址到高地址）：0x%02X 0x%02X\n", low, high);
    /* 大端低地址存高字节，所以先输出high，再输出low。 */
    printf("大端序（低地址到高地址）：0x%02X 0x%02X\n", high, low);
    /* 结束整个程序并返回0，表示正常完成。 */
    return 0;
}
