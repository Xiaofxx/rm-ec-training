# 第二次培训源码

标准答案每题单独编译。课堂示例保留讲义中的目录名称。源码为UTF-8，程序需自行编译生成。

多文件显示示例：
```sh
gcc -std=c11 -Wall -Wextra -finput-charset=UTF-8 -fexec-charset=UTF-8 main.c app.c ui.c display_pc.c -o program.exe
```
