#include <stdio.h> /* 提供printf声明。 */
int IsPrime(int number) /* 输入整数，返回0或1。 */
{
    if (number < 2) { /* 小于2不是素数。 */
        return 0; /* 返回否，并结束本次调用。 */
    }
    for (int divisor = 2; divisor <= number / divisor; divisor++) { /* 试除到平方根。 */
        if (number % divisor == 0) { /* 找到一个因数。 */
            return 0; /* 合数，无需继续。 */
        }
    }
    return 1; /* 未找到因数，因此是素数。 */
}
int main(void) /* 用同一判断完成多个输入的验证。 */
{
    int samples[4] = {1, 2, 49, 101}; /* 存放测试输入。 */
    for (int i = 0; i < 4; i++) { /* 遍历有效下标0到3。 */
        printf("%d: %d\n", samples[i], IsPrime(samples[i])); /* 使用函数结果。 */
    }
    return 0; /* 正常结束。 */
}
