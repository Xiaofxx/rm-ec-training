#ifndef APP_H /* 防止重复包含。 */
#define APP_H /* 设置保护标记。 */
void App_Init(void); /* 准备模拟业务状态。 */
int App_GetVoltage(void); /* 返回电压值，单位0.1V。 */
int App_GetState(void); /* 返回模拟运行状态。 */
#endif /* 结束头文件保护。 */
