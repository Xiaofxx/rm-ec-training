#include <stdio.h> /* 提供电脑终端输出。 */
#include "display.h" /* 核对实现与接口声明。 */
void Display_Init(void) /* 电脑模拟不初始化真实硬件。 */
{
    printf("电脑显示模拟已初始化。\n"); /* 提醒这不是OLED硬件运行。 */
}
void Display_ShowNumber(int row, int value) /* 可供不同界面复用。 */
{
    printf("第%d行：%d\n", row, value); /* 用终端模拟显示。 */
}
