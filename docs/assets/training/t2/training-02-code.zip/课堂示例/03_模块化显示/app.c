#include "app.h" /* 引入本模块公开接口。 */
void App_Init(void) /* 本课使用固定模拟数据，无额外初始化。 */
{
    /* 空函数体现接口位置，不代表真实工程可省略初始化。 */
}
int App_GetVoltage(void) /* 模拟业务数据来源。 */
{
    return 120; /* 表示12.0V，不是ADC实测值。 */
}
int App_GetState(void) /* 获取模拟运行状态。 */
{
    return 1; /* 本例约定1表示运行。 */
}
