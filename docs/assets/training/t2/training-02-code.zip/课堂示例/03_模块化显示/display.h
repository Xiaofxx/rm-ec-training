#ifndef DISPLAY_H /* 防止重复包含。 */
#define DISPLAY_H /* 设置保护标记。 */
void Display_Init(void); /* 初始化显示模块。 */
void Display_ShowNumber(int row, int value); /* 在指定行显示一个整数。 */
#endif /* 结束头文件保护。 */
