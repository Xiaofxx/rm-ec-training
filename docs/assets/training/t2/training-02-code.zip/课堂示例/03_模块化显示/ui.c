#include "ui.h" /* 引入当前模块接口。 */
#include "display.h" /* 调用显示模块，不直接操作硬件。 */
void UI_Update(int voltage, int state) /* 负责布局。 */
{
    int values[3] = {voltage, state, 35}; /* 第3项模拟温度35度。 */
    for (int i = 0; i < 3; i++) { /* 遍历三个业务值，下标0到2。 */
        Display_ShowNumber(i + 1, values[i]); /* 下标转换为1起始行号。 */
    }
}
