#ifndef UI_H /* 防止重复包含。 */
#define UI_H /* 设置保护标记。 */
void UI_Update(int voltage, int state); /* 接收数据并更新页面。 */
#endif /* 结束头文件保护。 */
