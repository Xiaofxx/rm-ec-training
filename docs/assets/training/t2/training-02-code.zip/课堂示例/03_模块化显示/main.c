#include "app.h" /* 获取业务接口。 */
#include "ui.h" /* 获取界面更新接口。 */
#include "display.h" /* 获取显示初始化接口。 */
int main(void) /* 组织流程，而不是实现全部细节。 */
{
    Display_Init(); /* 准备电脑显示模拟。 */
    App_Init(); /* 准备业务模块。 */
    UI_Update(App_GetVoltage(), App_GetState()); /* 数据交给界面，界面调用显示。 */
    return 0; /* 单次演示结束；真实固件通常持续循环工作。 */
}
