#include <stdio.h> /* 声明输入输出接口。 */
#include "max.h" /* 引入宏和调试开关。 */
int main(void) /* 程序入口。 */
{
    int result = MAX(2 + 5, 4); /* 观察预处理后宏替换的结果。 */
#ifdef DEBUG /* 定义DEBUG时编译本段。 */
    printf("DEBUG enabled\n"); /* 使用英文便于跨编码观察。 */
#endif /* 结束调试代码区域。 */
    printf("max = %d\n", result); /* 两种模式均输出5。 */
    return 0; /* 正常结束。 */
}
