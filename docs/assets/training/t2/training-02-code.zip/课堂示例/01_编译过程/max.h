#ifndef MAX_H /* 检查头文件是否已被包含。 */
#define MAX_H /* 标记此头文件已处理。 */
#define MAX(a,b) (((a) > (b)) ? (a) : (b)) /* 带参数宏，保护优先级。 */
#define DEBUG /* 定义时保留调试输出。 */
#endif /* 结束头文件保护。 */
